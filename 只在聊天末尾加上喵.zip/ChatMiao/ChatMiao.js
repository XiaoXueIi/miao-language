// ChatMiao.js - 适用于LeviLamina的聊天喵喵插件

ll.registerPlugin('ChatMiao', '聊天喵喵插件', [1, 0, 0]);

logger.info('=== 聊天喵喵插件开始加载 ===');

// 监听玩家聊天事件
mc.listen('onChat', (player, msg) => {
    try {
        // 获取玩家名和消息
        const playerName = player.name;
        
        // 关键修改：直接在原消息后面紧贴添加“喵”，不使用任何颜色代码
        const newMessage = `${msg}喵`;  // 去掉空格，紧贴文字
        
        // 使用tellraw保持原样格式发送，包括玩家名样式
        mc.broadcast(`<${playerName}> ${newMessage}`);
        
        // 在控制台也打印一份，方便调试
        logger.info(`[喵喵] <${playerName}> ${msg}喵`);
        
        // 返回 false 以取消原始聊天消息
        return false;
        
    } catch (error) {
        logger.error('处理聊天消息时出错: ' + error);
        // 如果出错，允许原始消息正常发送
        return true;
    }
});

logger.info('=== 聊天喵喵插件加载完成！ ===');